
package cap.basic;

import java.math.BigDecimal;
import java.util.ArrayList;

public class Sample1 {
	
	public static void main(String args[]){
		
		
	String testNameFromExe="456";
	String s="10.0";
	
	System.out.println("Big Decimal value+++++" +new BigDecimal(Float.valueOf(s)));
	System.out.println("Big Decimal value+++++" +s);
	ArrayList<String> al=new ArrayList<String>();
	al.add("123");
	al.add("456");
	for(String testname:al){
		if(testname.equalsIgnoreCase(testNameFromExe)){
			switch(testNameFromExe){
			case "123":
				System.out.println("Hiiiiiiiiii");
				continue;
			case "456":
				System.out.println("Byyyyyyyyyyyy");
				continue;
	default:
		System.out.println("Invalid");
		break;
				
			}
		}
	}
	
}
}
