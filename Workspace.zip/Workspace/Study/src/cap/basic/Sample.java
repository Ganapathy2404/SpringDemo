package cap.basic;
import cap.basic.*;

import java.util.*;  
class Sample{  
	
	static int size=0;
 public static void main(String args[]){  
	 
	 String[] array={"a","b"};
	 
	 String sa="";
	 if(sa.equals(null) && sa.isEmpty()){
		 
	 }
	 
	 ArrayList<String> al1 =new ArrayList<String>();
	 al1.add("123");
	 al1.add("345");
	 
	 ArrayList<String> al2=new ArrayList<String>();
	 al2.add("123");
	 al2.add("345");
	 al2.add("789");
	 size=al2.size();
	 for(String a:al1){
		 if(al2.contains(a)){
			 System.out.println("Fine Working---------");
			 
		 }
	 }
	 
	 boolean isTrue=addElementsToArrayList(al2);
	 System.out.println(isTrue);
	 
	
	 
	 ListIterator<String> ltr=al1.listIterator();
	 while(ltr.hasNext()){
		 System.out.println(ltr.next());
		 
	 }
	 while(ltr.hasPrevious()){
		 //System.out.println(ltr.previous());
		String str=ltr.previous();
		 if(str.equals("345")){
			  ltr.remove();
		 }
		 str=ltr.previous();
		 System.out.println(str);
	 }
	 
	 
   
	  
	 
	   HashSet<String> al=new HashSet<String>();  
	   al.add("Ravi");  
	   al.add("Vijay");  
	   al.add("Ravi");  
	   al.add("Ajay");  
	   System.out.println(al);
	   
	   Iterator<String> itr=al.iterator();  
	   while(itr.hasNext()){  
		   String string=itr.next();
		   if(string.equals("Vijay")){
			   System.out.println(string);
			   itr.remove(); 
		   }	     
		   System.out.println(string);	 
	  
	   }  
	   
	   
	    
	  }  
 
 
 private static boolean addElementsToArrayList(ArrayList<String> al2){
	 
	 try{
		 al2.add(3, "aaaa"); 
	 }
	 catch(Exception e){
		 System.out.println("Invalid index value");
	 }
	 if(size==al2.size()){
		 return true;
	 }
	 return false;
	 
	 
 }
 
  
 }  
 
