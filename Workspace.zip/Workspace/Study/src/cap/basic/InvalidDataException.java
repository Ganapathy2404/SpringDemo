package cap.basic;

public class InvalidDataException extends Exception{

	
	transient private String internalMessage;

	public InvalidDataException(String message){
		super(message);
	}

	public InvalidDataException(String message,Throwable cause){
		super(message,cause);		
	}
	
	public String getString(){
		return internalMessage;
	}

}
