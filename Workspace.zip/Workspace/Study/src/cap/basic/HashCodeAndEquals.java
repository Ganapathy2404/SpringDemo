package cap.basic;

import java.util.HashMap;

public class HashCodeAndEquals {
	private String color;

	public HashCodeAndEquals(String color) {
		// TODO Auto-generated constructor stub

		this.color = color;
	}

	public boolean equals(Object obj) {
		if (obj == null)
			return false;
		if (!(obj instanceof HashCodeAndEquals))
			return false;
		if (obj == this)
			return true;
		return this.color.equals(((HashCodeAndEquals) obj).color);
	}

	public int hashCode() {
		return this.color.hashCode();
	}

	public static void main(String[] args) {
		HashCodeAndEquals a1 = new HashCodeAndEquals("green");
		HashCodeAndEquals a2 = new HashCodeAndEquals("red");

		// hashMap stores apple type and its quantity
		HashMap<HashCodeAndEquals, Integer> m = new HashMap<HashCodeAndEquals, Integer>();
		m.put(a1, 10);
		m.put(a2, 20);
		System.out.println(m.get(new HashCodeAndEquals("green")));
	}
}