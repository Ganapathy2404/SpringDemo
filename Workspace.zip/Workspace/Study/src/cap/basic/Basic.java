package cap.basic;

public class Basic {
	int id;
	String name;
	Basic basic=null;
	Basic basic2;
	public Basic(int id, String name){
		this.id=id;
		this.name=name;
	}

	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Basic)) {
			return false;
		}
		if (obj == this)
			return true;

		return this.name.equals(((Basic) obj).name);

	}
	
	public int hashCode(){

		return this.name.hashCode();
		
	}

	
	public static void main(String[] args) {

		
		 

		
		Basic basic2 =new Basic(10,"Ajit");

		
		System.out.println(basic2.hashCode());

		System.out.println(basic2.equals(new Basic(30,"Ajit")));

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
