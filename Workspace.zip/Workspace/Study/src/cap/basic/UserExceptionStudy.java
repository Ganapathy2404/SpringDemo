package cap.basic;

public class UserExceptionStudy {
	public static void main(String[] args) {
		try{
		getCalculations();
		}
		catch(InvalidDataException e){
			System.out.println("Value for sum" +e.getMessage());
			System.out.println("Actual message"+e.getCause());
		}

	}
	private static void getCalculations() throws InvalidDataException{
		int a=10,b=20;
		int sum=a+b;
		System.out.println("Sum for variable:" +sum);
		if(sum==30){
			throw new InvalidDataException(String.format("Wrong value for sum: %d :%s",sum,"Not working"));
		}
		System.out.println("Running successfully");
	}

}
