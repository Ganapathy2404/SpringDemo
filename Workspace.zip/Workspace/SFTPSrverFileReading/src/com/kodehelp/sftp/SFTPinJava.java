/**
*
*/
package com.kodehelp.sftp;
 
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
 
import java.util.Vector;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
 
/**
* @author kodehelp
*
*/
public class SFTPinJava {
 
/**
*
*/
public SFTPinJava() {
// TODO Auto-generated constructor stub
}
 
/**
* @program to read file from sftp server
*/
public static void main(String[] args) {
String SFTPHOST = "test.rebex.net";
int    SFTPPORT = 22;
String SFTPUSER = "demo";
String SFTPPASS = "password";
String SFTPWORKINGDIR = "/pub/example/";
 
Session     session     = null;
Channel     channel     = null;
ChannelSftp channelSftp = null;
 
try{
JSch jsch = new JSch();
 
session = jsch.getSession(SFTPUSER,SFTPHOST,SFTPPORT);
session.setPassword(SFTPPASS);
java.util.Properties config = new java.util.Properties();
config.put("StrictHostKeyChecking", "no");
session.setConfig(config);
session.connect();
channel = session.openChannel("sftp");
channel.connect();
channelSftp = (ChannelSftp)channel;
channelSftp.cd(SFTPWORKINGDIR);
byte[] buffer = new byte[1024];

 
 
 Vector<LsEntry> filelist = channelSftp.ls("*.png");
for(int i=0; i<filelist.size();i++){
	LsEntry entry=(LsEntry)filelist.get(i);
    System.out.println(filelist.get(i).toString());
    System.out.println(entry.getFilename()+"----------------");
    
} 
BufferedInputStream bis = new BufferedInputStream(channelSftp.get("readme.txt"));
File newFile = new File("D:/SampleSftp/readme.txt");
OutputStream os = new FileOutputStream(newFile);
BufferedOutputStream bos = new BufferedOutputStream(os);
int readCount;
//System.out.println("Getting: " + theLine);
while( (readCount = bis.read(buffer)) > 0) {
System.out.println("Writing: " );
bos.write(buffer, 0, readCount);
System.out.println("Succesfully file wrriten to the destination");
}
bis.close();
bos.close();
}catch(Exception ex){
ex.printStackTrace();
}
 
}
 
}