package com.kodehelp.sftp;

import java.util.ArrayList;

public class IsoCodeAccess {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<IsoCode> al=new ArrayList<IsoCode>();
		 
		IsoCode e = IsoCode.Test1;
		
		String name = e.name(); // Returns "Test1"
		System.out.println(name);

	}

}
