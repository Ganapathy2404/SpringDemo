package com.kodehelp.sftp;

public enum IsoCode {
	Test1, Test2, Test3
	
	

}

