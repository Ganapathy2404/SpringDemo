package com.crunchify.tutorial;

public class Ajit {
	
	/**
	 * @param args
	 */
 
	
	Long reference=3333333333333333L;
	
	
	public static void main(String args[]){
		Sample sample= new Sample();		
		Long l=12346942536468358l;
		sample.setReference1(l);
		System.out.println("Hi this prints the value for the Sample class object"+(Long)sample.getReference1());
		 
		
	}

}
