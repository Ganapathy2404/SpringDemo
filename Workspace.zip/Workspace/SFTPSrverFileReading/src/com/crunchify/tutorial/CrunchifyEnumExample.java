package com.crunchify.tutorial;
 
/**
 * @author Crunchify.com
 */
 
public class CrunchifyEnumExample {
 
	public enum Company {
		EBAY("100001"), PAYPAL("10002"), GOOGLE("10003");
		private String value;
 
		private Company(String value) {
			this.value = value;
		}
	}
 
	public static void main(String[] args) {
		for (Company cName : Company.values()) {
			System.out.println("Company Value: " + cName.value + " - Company Name: " + cName);
		}
	}
}
