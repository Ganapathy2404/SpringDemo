package com.crunchify.tutorial;

public class Sample {
	
	Object reference1;

	public Object getReference1() {
		return reference1;
	}

	public void setReference1(Object reference1) {
		this.reference1 = reference1;
	}

}
