
public class BooleanCheckSample {
	private static boolean status=false;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		status=checkStatus();
		if(status){
			System.out.println("Hi fine value comming from the above programm...");
		}else{
			System.out.println("no fine value commes");
		}

	}
	private static boolean checkStatus(){
		return true;
	}
}
