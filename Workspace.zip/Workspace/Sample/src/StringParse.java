import java.io.ObjectInputStream.GetField;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;


public class StringParse {

	/**
	 * Developed on 2/9/2016
	 * This class is created to find out the first part,middle part and last part of the string from String and also if there are any unwanted 
	 * characters are there in the string then remove characters from string
	 * pattern to allow special characters=[^a-zA-Z\\d$\\ ]
	 * test.replaceAll("^ +| +$|( )+", "$1")
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		final Pattern PATTERN_FIRST_LAST_NAME=Pattern.compile("[^a-zA-Z\\ ]");
		String name="  Ajit  Bapurao          Nikam    s  ";			
		String afterFirstLastSpaceRemoval=name.replaceAll("^ +| +$|( )+", "$1");
		System.out.println("String after3333333333 triming :" +afterFirstLastSpaceRemoval);
		int lengthOfName=afterFirstLastSpaceRemoval.length();
		if(lengthOfName==0){
			System.out.println("empty string");
			return;
		}
		System.out.println("Total name after Pattern Compilation :"+returnTotalNameAfterPatternCompilation(name, PATTERN_FIRST_LAST_NAME, lengthOfName));

		String firstName=checkFirstNameAndLastName(afterFirstLastSpaceRemoval, PATTERN_FIRST_LAST_NAME, lengthOfName);
		System.out.println("First Name After processing Complete name :"+firstName.trim());			

	}

	private static String returnTotalNameAfterPatternCompilation(String name, Pattern regex,int length){
		if(name!=null && !name.isEmpty() ){
			String validName=name.replaceAll(String.valueOf(regex),"");			
			return validName;
		}
		return null;
	}


	private static String checkFirstNameAndLastName(String name, Pattern regex,int length){
		if(name!=null && !name.isEmpty() ){
			
			String validName=name.replaceAll(String.valueOf(regex),"");
			System.out.println("Valid name after removal of unwanted characters from the String : "+validName);

			int stringFirstSpacePossition=findFirstSpacePossition(validName);
			
			if(stringFirstSpacePossition==0){
				System.out.println("The Total name contains only first name Last name and Middle name not available");
				System.out.println("First Name is : "+validName.trim());
				return validName;
			}

			int stringLastSpacePossition=findLastSpacePossition(validName);				
			System.out.println("Last name after processing : "+validName.substring(stringLastSpacePossition+1, validName.length()).trim());

			if(stringFirstSpacePossition==stringLastSpacePossition){				
				System.out.println("Middle name not available");				
			}else{
				System.out.println("Middle name after processing : "+validName.substring(stringFirstSpacePossition,stringLastSpacePossition).trim());
			}			
			return validName.substring(0, stringFirstSpacePossition);
		}
		return null;
	}

	private static int findFirstSpacePossition(String str){
		int length=0;		
		if(!str.isEmpty() || str==null){
			for(int i=0;i<str.length();i++){
				char c=str.charAt(i);				
				if(c==' '){					
					length=i;
					return length;
				}
				else{
					System.out.println("No white spaces in the string");
				}
			}
			return length;
		}
		return length;
	}

	private static int findLastSpacePossition(String str){
		int length=str.length();
		System.out.println("length of string for last name ** "+length);
		int possition=0;
		if(!str.isEmpty() || str==null){
			System.out.println("String is not empty Value of parse string }}}" +str);
			for(int i=length-1;i>0;i--){
				char c=str.charAt(i);				
				if(c==' '){		
					System.out.println("Value of I for Last space 000 "+i);
					possition=i;
					return possition;
				}
				else{
					System.out.println("No white spaces in the string");
				}
			}
			return possition;
		}
		return 0;
	}


}
