


public class SampleTry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		checkStatus();

	}
	
	private static void checkStatus(){
		int a,b;
		boolean result=false;
		result=checkStatus1();
		if(result){
			System.out.println("successfuly given value");
		}else{
			System.out.println("Got error");	
		}
		
		result=checkStatus1();
			
		
	}
	private static boolean checkStatus1()
	{
		try{
			int a=10,b=0,c;
			c=a/b;
			System.out.println("Value of C:::"+c);
			
		}catch(Exception e){
			System.out.println("Throwing exception");
			return false;
		}
		return false;
	}
}
