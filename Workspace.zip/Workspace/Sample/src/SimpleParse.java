
public class SimpleParse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String sample="   Ajit    Nikam ";
		String afterRemoval=sample.replaceAll("^ +| +$|( )+", "$1");
		System.out.println("After Removal :"+afterRemoval);

	}

}
