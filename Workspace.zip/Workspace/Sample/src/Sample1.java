import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


public class Sample1 {

	public static <E> void main(String[] args) {
		// TODO Auto-generated method stub
		boolean status=false;
		
		try{
			for(int i=0;i<5;i++){
				for(int j=1; j<2;j++){
					if(i==j){
						System.out.println("Hello");
						status=false;
						break;
					}
					
					
				}
				if(status==true){
					break;
				}
				continue;
			}
		}catch(Exception e){
			System.out.println("Hiiii");
		}
		
		Set<String> setStrings=null;
		setStrings=find();
		for(String str:setStrings){
			System.out.println(str);
		}
		System.out.println(setStrings.size());
		
		if(setStrings.isEmpty()){
			System.out.println("Hiiiiii");
		}
		else{
			System.out.println("Not Hiiiiii");
		}

	}
	
	private static Set<String> find(){
		Set<String> setStrings=new HashSet<String>();
		setStrings.add("Ajit");
		setStrings.add("Ajit");
		setStrings.add("Ajit");
		setStrings.add("Amol");
		setStrings.add("Amol");
		return setStrings;
	}

}
