
public class EnumsFromString {

	public enum Blah {
		A("text1"),
		B("text2"),
		C("text3"),
		D("text4");

		private String text;

		Blah(String text) {
			this.text = text;
		}

		public String getText() {
			return this.text;
		}

		public static Blah fromString(String text) {
			if (text != null) {
				for (Blah b : Blah.values()) {
					if (text.equalsIgnoreCase(b.text)) {
						return b;
					}
				}
			}
			return null;
		}

		public static <T extends Enum<?>> T lookup(Class<T> enumType,
				String name) {
			for (T enumn : enumType.getEnumConstants()) {
				if (enumn.name().equalsIgnoreCase(name)) {
					return enumn;
				}
			}
			return null;
		}

	}
	public static void main(String args[]){
		Blah b=EnumsFromString.Blah.fromString("text1");
		Blah b1=EnumsFromString.Blah.lookup(Blah.class, "text1");
		
		System.out.println(b1);
	}

}
