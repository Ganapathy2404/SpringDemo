package com.cg.SL1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//Spring Using Application Context and Property Initialization(Setter Injection)
public class DrawingApp {
	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("app1.xml");
		Triangle t=(Triangle)context.getBean("t");
		t.draw();
	}

}
