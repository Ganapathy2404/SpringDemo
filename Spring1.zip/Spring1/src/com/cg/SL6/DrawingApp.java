package com.cg.SL6;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//Inner Beans
public class DrawingApp {
	public static void main(String[] args) {
		//Triangle t=new Triangle();
		ApplicationContext context=new ClassPathXmlApplicationContext("app6.xml");
		Triangle t=(Triangle)context.getBean("t");
		t.draw();
	}

}
