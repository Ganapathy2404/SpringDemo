package com.cg.SL;

public class Triangle {
public void draw(){
	System.out.println("Triangle drawn");
}
}
