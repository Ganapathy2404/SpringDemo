package com.cg.SL2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//Spring Using Application Context and Constructor Injection 1
public class DrawingApp {
	public static void main(String[] args) {
		//Triangle t=new Triangle();
		ApplicationContext context=new ClassPathXmlApplicationContext("app2.xml");
		Triangle t=(Triangle)context.getBean("t");
		t.draw();
	}

}
