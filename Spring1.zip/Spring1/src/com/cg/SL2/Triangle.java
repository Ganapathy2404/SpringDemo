package com.cg.SL2;

public class Triangle {
	private String type;
	
	//A constructor is created
	public Triangle(String type){
		this.type=type;
	}
	
	//Getter is used for calling the Constructor
	public String getType() {
		return type;
	}

	

	public void draw(){
	System.out.println(getType()+ " Triangle drawn");
}
}
