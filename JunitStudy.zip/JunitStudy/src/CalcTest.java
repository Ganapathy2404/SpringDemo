import static org.junit.Assert.*;

import org.junit.Test;
import static org.mockito.Mockito.*;

public class CalcTest {
	
	Calc c1 = new Calc();

	@Test
	public void addTest() {

		int a = 10, b = 5;
		int d = a + b;
		Calc c = mock(Calc.class);
		when(c.add(anyInt(), anyInt())).thenReturn(d);
		assertEquals(c.add(a, b), d);
	}

	@Test
	public void subTest() {
		int a = 10, b = 5;
		int c = a - b;
		assertEquals(c, c1.sub(10, 5));
	}

	@Test
	public void divTest() {
		int a = 10, b = 5;
		int c = a / b;
		assertEquals(c, c1.div(10, 5));
	}
	
	@Test(expected = ArithmeticException.class)
	public void divTest1() {
		int a = 10, b = 0;
		int c = a / b;
		assertEquals(c, c1.div(10, 0));
	}
	
	@Test
	public void subTest1() {
		int a = 10, b = 5;
		int c = a - b;
		int result  =   c1.sub(10,6);
		boolean status = false;
		if(c == result){
			status = true;
		}
		
		assertFalse(status);
		
	}
	
	
}