
public class Calc {
	public int add(int a,int b){
		System.out.println(" inside add ");
		return (a+b);
	}
	public int sub(int a,int b){
		return (a-b);
	}
	public int mul(int a,int b){
		return (a*b);
	}
	public int div(int a,int b){
		return (a/b);
	}
	/*public static void main(String[] args) {
		Calc c=new Calc();
		
		System.out.println(c.Add(10, 5));
	}*/

}
