package com.cg.SL13;

public interface Shape {
	public void draw();

}
