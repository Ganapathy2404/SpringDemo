package com.cg.SL13;

public class Point {
	private int x;
	private int y;
	private int radiusval;
	
	
	public int getRadiusval() {
		return radiusval;
	}
	public void setRadiusval(int radiusval) {
		this.radiusval = radiusval;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	
}
