package com.cg.SL13;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//Using Collection 
public class DrawingApp {
	public static void main(String[] args) {
		//Triangle t=new Triangle();
		ApplicationContext context=new ClassPathXmlApplicationContext("app12.xml");
		Circle s=(Circle)context.getBean("c");
		s.draw();
	}

}
 