package com.cg.SL;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//Spring Using Application Context
public class DrawingApp {
	public static void main(String[] args) {
		
		/*Normal java snippet
		
		Triangle t=new Triangle();
		t.draw();
		*/
		
		
		ApplicationContext context=new ClassPathXmlApplicationContext("app.xml");
		
		//Triangle is the Triangle.java code
		//t is used in app.xml
		
		Triangle t=(Triangle)context.getBean("t");
		t.draw();
	}

}
