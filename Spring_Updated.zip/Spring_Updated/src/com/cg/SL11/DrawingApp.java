package com.cg.SL11;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//Bean Definition Inheritance
public class DrawingApp {
	public static void main(String[] args) {
		//Triangle t=new Triangle();
		ApplicationContext context=new ClassPathXmlApplicationContext("app11.xml");
		Triangle t=(Triangle)context.getBean("t2");
		t.draw();
	}

}
