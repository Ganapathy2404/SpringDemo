package com.cg.SL04;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//Spring Using Application Context and Constructor Injection 3
public class DrawingApp {
	public static void main(String[] args) {
		//Triangle t=new Triangle();
		ApplicationContext context=new ClassPathXmlApplicationContext("app04.xml");
		Triangle t=(Triangle)context.getBean("t");
		t.draw();
	}

}
