package com.cg.SL14;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
// Java Annotation-indicates that the class can be used by the Spring IoC
// container as a source of bean definitions.
public class Triangle {
	@Bean
	// Java Annotation-tells Spring that a method annotated with @Bean will
	// return an object that should be registered as a bean in the Spring
	// application context.
	public Draw draw() {
		return new Draw();
	}
}
