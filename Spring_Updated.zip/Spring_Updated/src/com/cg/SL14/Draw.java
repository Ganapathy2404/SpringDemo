package com.cg.SL14;

public class Draw {
	private String message;

	public void setMessage(String message) {
		this.message = message;
	}

	public void getMessage() {
		System.out.println("The output is: " + message);
	}

}
