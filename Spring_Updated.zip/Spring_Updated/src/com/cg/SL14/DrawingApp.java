package com.cg.SL14;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

//Using Java Annotations
//Java-based configuration option enables you to write most of your 
//Spring configuration without XML but with the help of few Java-based annotations 
public class DrawingApp {
	public static void main(String[] args) {

		ApplicationContext c = new AnnotationConfigApplicationContext(
				Triangle.class);

		Draw d = c.getBean(Draw.class);
		d.setMessage("Drawing Square");
		d.getMessage();
	}

}
