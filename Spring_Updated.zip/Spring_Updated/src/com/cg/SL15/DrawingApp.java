package com.cg.SL15;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.SL15.Triangle;

//Using Java Annotations
//Java-based configuration option enables you to write most of your 
//Spring configuration without XML but with the help of few Java-based annotations 
public class DrawingApp {
	public static void main(String[] args) {

		ApplicationContext context=new ClassPathXmlApplicationContext("app15.xml");

		Triangle m=(Triangle)context.getBean("m");
		m.draw();
	}

}
