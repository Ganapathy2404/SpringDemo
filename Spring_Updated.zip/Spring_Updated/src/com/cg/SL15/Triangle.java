package com.cg.SL15;

public class Triangle {
	public void draw() {
		System.out.println("Triangle drawn");
	}
}
