package com.cg.SL01;

public class Triangle {
	private String type1;

	public String getType1() {
		return type1;
	}

	public void setType1(String type1) {
		this.type1 = type1;
	}

	public void draw() {
		System.out.println(getType1() + " Triangle drawn");
	}
}
