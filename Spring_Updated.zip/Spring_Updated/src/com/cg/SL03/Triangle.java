package com.cg.SL03;

public class Triangle {
	private String type;
	private int height;

	// A constructor is created for type
	public Triangle(String type) {
		this.type = type;
	}

	// A constructor is created for type and height
	public Triangle(int height, String type) {
		this.type = type;
		this.height = height;
	}

	// Getter is used for calling the Constructor
	public String getType() {
		return type;
	}

	// Getter is used for calling the Constructor
	public int getHeight() {
		return height;
	}

	public void draw() {
		System.out.println(getType() + " Triangle drawn with a height of :"
				+ getHeight());
	}
}
