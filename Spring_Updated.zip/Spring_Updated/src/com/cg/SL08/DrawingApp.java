package com.cg.SL08;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//Bean Autowiring 
public class DrawingApp {
	public static void main(String[] args) {
		//Triangle t=new Triangle();
		ApplicationContext context=new ClassPathXmlApplicationContext("app8.xml");
		Triangle t=(Triangle)context.getBean("t");
		t.draw();
	}

}
