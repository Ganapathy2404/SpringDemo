package com.cg.SL12;

public interface Shape {
	public void draw();

}
